<?php $__env->startSection('title', 'Обзор теста | Znatok-KG'); ?>

<?php $__env->startSection('content'); ?>

    <div class="breadcrumbarea" data-aos="fade-up">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="breadcrumb__content__wraper">
                        <div class="breadcrumb__title">
                            <h2 class="heading">Тест</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="shape__icon__2">
            <img loading="lazy" class="shape__icon__img shape__icon__img__1" src="<?php echo e(asset('assets/img/herobanner/herobanner__1.png')); ?>" alt="photo" />
            <img loading="lazy" class="shape__icon__img shape__icon__img__2" src="<?php echo e(asset('assets/img/herobanner/herobanner__2.png')); ?>" alt="photo" />
            <img loading="lazy" class="shape__icon__img shape__icon__img__3" src="<?php echo e(asset('assets/img/herobanner/herobanner__3.png')); ?>" alt="photo" />
            <img loading="lazy" class="shape__icon__img shape__icon__img__4" src="<?php echo e(asset('assets/img/herobanner/herobanner__5.png')); ?>" alt="photo" />
        </div>
    </div>

    <div class="tution sp_bottom_100 sp_top_100">
        <div class="container-fluid full__width__padding">
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12" data-aos="fade-up">
                    <div class="accordion content__cirriculum__wrap" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                    Название теста: <?php echo e($test->title); ?>

                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="scc__wrap">
                                        <div class="scc__info">
                                            <h5><span>Описание теста: <?php echo e($test->description); ?></span></h5>
                                        </div>
                                    </div>
                                    <div class="scc__wrap">
                                        <div class="scc__info">
                                            <h5><span>Раздел теста: <?php echo e($test->section->title); ?></span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12" data-aos="fade-up">
                    <form action="<?php echo e(route('test.submit', $test->id)); ?>" method="POST" id="test-form">
                        <?php echo csrf_field(); ?>

                        <div class="lesson__quiz__wrap">
                            <div class="quiz__single__attemp">
                                <ul>
                                    <li>Вопросов : <?php echo e($test->questions->count()); ?></li>
                                </ul>
                                <hr class="hr" />
                            </div>

                            <?php $__currentLoopData = $test->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="quiz__single__attemp">
                                    <hr class="hr" />
                                    <h3><?php echo e($qIndex + 1); ?>. <?php echo e($question->text); ?></h3>
                                    <div class="row">
                                        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input
                                                        class="form-check-input"
                                                        type="checkbox"
                                                        name="answers[<?php echo e($question->id); ?>][]"
                                                        id="question<?php echo e($question->id); ?>_answer<?php echo e($answer->id); ?>"
                                                        value="<?php echo e($answer->id); ?>"
                                                    />
                                                    <label class="form-check-label" for="question<?php echo e($question->id); ?>_answer<?php echo e($answer->id); ?>">
                                                        <?php echo e($answer->text); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button class="default__button mt-4" type="submit">
                                Завершить
                                <i class="icofont-long-arrow-right"></i>
                            </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel-6-2-5\OSPanel\home\znatok-kg\resources\views/users/test/show-test.blade.php ENDPATH**/ ?>