


<?php $__env->startSection('title', 'Мои курсы | Znatok-KG '); ?>

<?php $__env->startSection('content-user'); ?>

    <div class="col-xl-9 col-lg-9 col-md-12">
        <div class="dashboard__content__wraper">
            <div class="dashboard__section__title">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('teacher')): ?>
                    <h4>Статус курса</h4>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student')): ?>
                    <h4>Мои курсы</h4>
                    <form action="<?php echo e(route('student.add-course')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                            <div class="dashboard__form__wraper">
                                <div class="dashboard__form__input">
                                    <label for="course-code">Добавить курс</label>
                                    <div class="input-group  dashboard__form__input">
                                        <input
                                            type="text"
                                            name="course_code"
                                            id="course-code"
                                            class="form-control"
                                            placeholder="Введите код курса"

                                        />
                                        <button
                                            class="create__course__bottom__button_top"
                                            type="submit"
                                            id="generate-code-btn"
                                        >
                                            Добавить курс
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('teacher')): ?>
                <div class="row">
                    <div class="col-xl-12 aos-init aos-animate" data-aos="fade-up">

                        <ul class="nav  about__button__wrap dashboard__button__wrap" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="single__tab__link active" data-bs-toggle="tab"
                                        data-bs-target="#projects__one" type="button" aria-selected="true"
                                        role="tab">Публиковать
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="single__tab__link" data-bs-toggle="tab"
                                        data-bs-target="#projects__two" type="button" aria-selected="false"
                                        role="tab" tabindex="-1">В ожидании
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="single__tab__link" data-bs-toggle="tab"
                                        data-bs-target="#projects__three" type="button" aria-selected="false"
                                        role="tab" tabindex="-1">Черновик
                                </button>
                            </li>
                        </ul>


                    </div>
                    <div class="tab-content tab__content__wrapper aos-init aos-animate" id="myTabContent"
                         data-aos="fade-up">

                        <div class="tab-pane fade active show" id="projects__one" role="tabpanel"
                             aria-labelledby="projects__one">
                            <div class="row">

                                <?php $__empty_1 = true; $__currentLoopData = $publishedCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="gridarea__wraper">
                                            <div class="gridarea__img">
                                                <img
                                                    loading="lazy"
                                                    src="<?php echo e($course->cover ? asset('uploads/' . $course->cover) : asset('img/default.png')); ?>"
                                                    style="height: 250px; object-fit: cover; width: 100%;"
                                                >
                                                <div class="gridarea__small__button">
                                                    <div class="grid__badge blue__color"><?php echo e($course->category); ?></div>
                                                </div>


                                            </div>
                                            <div class="gridarea__content">
                                                <div class="gridarea__list">
                                                    <ul>
                                                        <li>
                                                            <i class="icofont-book-alt"></i>
                                                            <?php echo e($course->sections->flatMap->lectures->count()); ?> лек.
                                                        </li>


                                                    </ul>
                                                </div>
                                                <div class="gridarea__heading">
                                                    <h3>
                                                        <a href="<?php echo e(route('course.details-course', $course->id)); ?>"><?php echo e($course->title); ?></a>
                                                    </h3>
                                                </div>

                                                <div class="gridarea__bottom">

                                                        <div class="gridarea__small__img flex-wrap">

                                                            <div class="gridarea__small__content ">
                                                                <h6>
                                                                    Автор: <?php echo e($course->teacher->first_name); ?> <?php echo e($course->teacher->last_name); ?></h6>
                                                                <form action="<?php echo e(route('teacher.delete-course',$course->id )); ?>" method="POST" onsubmit="return confirm('Вы уверены, что хотите удалить курс');">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button
                                                                        class="create__course__bottom__button_top mt-2"
                                                                        type="submit"
                                                                    >
                                                                        Удалить курс
                                                                    </button>
                                                                </form>

                                                            </div>

                                                        </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('teacher')): ?>
                                        <div class="fs-6">Список опубликованных <br> курсов пуст!</div>
                                    <?php endif; ?>

                                <?php endif; ?>


                            </div>
                        </div>

                        <div class="tab-pane fade" id="projects__two" role="tabpanel"
                             aria-labelledby="projects__two">

                            <div class="row">


                                <?php $__empty_1 = true; $__currentLoopData = $pendingCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="gridarea__wraper">
                                            <div class="gridarea__img">
                                                <img
                                                    loading="lazy"
                                                    src="<?php echo e($course->cover ? asset('uploads/' . $course->cover) : asset('img/default.png')); ?>"
                                                    style="height: 250px; object-fit: cover; width: 100%;"
                                                >
                                                <div class="gridarea__small__button">
                                                    <div class="grid__badge blue__color"><?php echo e($course->category); ?></div>
                                                </div>


                                            </div>
                                            <div class="gridarea__content">
                                                <div class="gridarea__list">
                                                    <ul>
                                                        <li>
                                                            <i class="icofont-book-alt"></i>
                                                            <?php echo e($course->sections->flatMap->lectures->count()); ?> лек.
                                                        </li>


                                                    </ul>
                                                </div>
                                                <div class="gridarea__heading">
                                                    <h3>
                                                        <a href="<?php echo e(route('course.details-course', $course->id)); ?>"><?php echo e($course->title); ?></a>
                                                    </h3>
                                                </div>

                                                <div class="gridarea__bottom">

                                                        <div class="gridarea__small__img flex-wrap">

                                                            <div class="gridarea__small__content">
                                                                <h6>
                                                                    Автор: <?php echo e($course->teacher->first_name); ?> <?php echo e($course->teacher->last_name); ?></h6>
                                                                <form action="<?php echo e(route('teacher.delete-course', $course->id)); ?>" method="POST" onsubmit="return confirm('Вы уверены, что хотите удалить курс');">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button
                                                                        class="create__course__bottom__button_top mt-2"
                                                                        type="submit"
                                                                    >
                                                                        Удалить курс
                                                                    </button>
                                                                </form>
                                                            </div>

                                                        </div>



                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="fs-6">Список опубликованных <br> курсов пуст!</div>
                                <?php endif; ?>


                            </div>

                        </div>

                        <div class="tab-pane fade" id="projects__three" role="tabpanel"
                             aria-labelledby="projects__three">
                            <div class="row">

                                <?php $__empty_1 = true; $__currentLoopData = $draftCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="gridarea__wraper">
                                            <div class="gridarea__img">
                                                <img
                                                    loading="lazy"
                                                    src="<?php echo e($course->cover ? asset('uploads/' . $course->cover) : asset('img/default.png')); ?>"
                                                    style="height: 250px; object-fit: cover; width: 100%;"
                                                >
                                                <div class="gridarea__small__button">
                                                    <div class="grid__badge blue__color"><?php echo e($course->category); ?></div>
                                                </div>


                                            </div>
                                            <div class="gridarea__content">
                                                <div class="gridarea__list">
                                                    <ul>
                                                        <li>
                                                            <i class="icofont-book-alt"></i>
                                                            <?php echo e($course->sections->flatMap->lectures->count()); ?> лек.
                                                        </li>


                                                    </ul>
                                                </div>
                                                <div class="gridarea__heading">
                                                    <h3>
                                                        <a href="<?php echo e(route('course.details-course', $course->id)); ?>"><?php echo e($course->title); ?></a>
                                                    </h3>
                                                </div>

                                                <div class="gridarea__bottom">

                                                        <div class="gridarea__small__img ">

                                                            <div class="gridarea__small__content">
                                                                <h6>
                                                                    Автор: <?php echo e($course->teacher->first_name); ?> <?php echo e($course->teacher->last_name); ?></h6>
                                                                <form action="<?php echo e(route('teacher.delete-course', $course->id)); ?>" method="POST" onsubmit="return confirm('Вы уверены, что хотите удалить курс');">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button
                                                                        class="create__course__bottom__button_top mt-2"
                                                                        type="submit"
                                                                    >
                                                                        Удалить курс
                                                                    </button>
                                                                </form>

                                                            </div>

                                                        </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="fs-6">Список опубликованных <br> курсов пуст!</div>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                </div>

            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student')): ?>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $addedCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="gridarea__wraper">
                                <div class="gridarea__img">
                                    <img
                                        loading="lazy"
                                        src="<?php echo e($course->cover ? asset('uploads/' . $course->cover) : asset('img/default.png')); ?>"
                                        style="height: 250px; object-fit: cover; width: 100%;"
                                    >
                                    <div class="gridarea__small__button">
                                        <div class="grid__badge blue__color"><?php echo e($course->category); ?></div>
                                    </div>
                                </div>
                                <div class="gridarea__content">
                                    <div class="gridarea__list">
                                        <ul>
                                            <li>
                                                <i class="icofont-book-alt"></i>
                                                <?php echo e($course->sections->flatMap->lectures->count()); ?> лек.
                                            </li>

                                        </ul>
                                    </div>
                                    <div class="gridarea__heading">
                                        <h3>
                                            <a href="<?php echo e(route('course.details-course', $course->id)); ?>"><?php echo e($course->title); ?></a>
                                        </h3>
                                    </div>
                                    <div class="gridarea__bottom">
                                        <div class="gridarea__small__content ">
                                            <h6>
                                                Автор: <?php echo e($course->teacher->first_name); ?> <?php echo e($course->teacher->last_name); ?></h6>

                                            <form action="<?php echo e(route('student.leave-course', $course->id)); ?>" method="POST" onsubmit="return confirm('Вы уверены, что хотите покинуть этот курс?');">
                                                <?php echo csrf_field(); ?>
                                                <button
                                                    class="create__course__bottom__button_top mt-2"
                                                    type="submit"
                                                >
                                                    Покинуть курс
                                                </button>
                                            </form>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        Вы пока не добавили ни одного курса.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.user-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel-6-2-5\OSPanel\home\znatok-kg\resources\views/users/course/index-course.blade.php ENDPATH**/ ?>