<?php $__env->startSection('title', 'Курсы | Znatok-KG '); ?>

<?php $__env->startSection('content'); ?>


    <div class="breadcrumbarea">

        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="breadcrumb__content__wraper" data-aos="fade-up">
                        <div class="breadcrumb__title">
                            <h2 class="heading">Все курсы</h2>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="shape__icon__2">
            <img loading="lazy"  class=" shape__icon__img shape__icon__img__1" src="<?php echo e(asset('assets/img/herobanner/herobanner__1.png')); ?>" alt="photo">
            <img loading="lazy"  class=" shape__icon__img shape__icon__img__2" src="<?php echo e(asset('assets/img/herobanner/herobanner__2.png')); ?>" alt="photo">
            <img loading="lazy"  class=" shape__icon__img shape__icon__img__3" src="<?php echo e(asset('assets/img/herobanner/herobanner__3.png')); ?>" alt="photo">
            <img loading="lazy"  class=" shape__icon__img shape__icon__img__4" src="<?php echo e(asset('assets/img/herobanner/herobanner__5.png')); ?>" alt="photo">
        </div>

    </div>
    <!-- breadcrumbarea__section__end-->

    <!-- course__section__start -->
    <div class="coursearea sp_top_100 sp_bottom_100">
        <div class="container">
            <div class="row">

                <!-- левая панель -->
                <div class="col-xl-3 col-lg-3 col-md-4 col-12">
                    <div class="course__sidebar__wraper" data-aos="fade-up">
                        <div class="course__heading">
                            <h5>Найти курс</h5>
                        </div>
                        <form action="<?php echo e(route('courses')); ?>" method="get">
                            <div class="course__input">
                                <input type="text" name="title" placeholder="Найти"
                                       value="<?php echo e($filters['title'] ?? ''); ?>">
                                <div class="search__button">
                                    <button type="submit"><i class="icofont-search-1"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="course__sidebar__wraper" data-aos="fade-up">
                        <div class="categori__wraper">
                            <div class="course__heading">
                                <h5>Категории</h5>
                            </div>
                            <div class="course__categories__list">
                                <ul>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('courses', ['category' => $category])); ?>">
                                                <?php echo e($category); ?>

                                                <span>
                                                <?php echo e(\App\Models\Course::where('category', $category)->count()); ?>

                                            </span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- правая часть -->
                <div class="col-xl-9 col-lg-9 col-md-8 col-12">

                    <div class="tab-content tab__content__wrapper with__sidebar__content" id="myTabContent">

                        <div class="tab-pane fade show active" id="projects__one" role="tabpanel" aria-labelledby="projects__one">
                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6 col-12 mb-2" data-aos="fade-up">
                                        <div class="gridarea__wraper gridarea__wraper__2 card-container">
                                            <div class="gridarea__img">
                                                <img loading="lazy" src="<?php echo e(asset('uploads/' . $course->cover)); ?>" alt="<?php echo e($course->title); ?>">
                                                <div class="gridarea__small__button">
                                                    <div class="grid__badge blue__color"><?php echo e($course->category); ?></div>
                                                </div>
                                            </div>
                                            <div class="gridarea__content card-content">
                                                <div class="gridarea__list">
                                                    <ul class="d-flex flex-wrap">
                                                        <li><i class="icofont-book-alt"></i> <?php echo e($course->lessons_count ?? 0); ?> ур.</li>

                                                    </ul>
                                                </div>
                                                <div class="gridarea__heading">
                                                    <h3><a href="<?php echo e(route('course.details-course', $course->id)); ?>"><?php echo e($course->title); ?></a></h3>
                                                </div>
                                                <div class="gridarea__bottom card-footer">
                                                    <a href="#">
                                                        <div class="gridarea__small__img">
                                                            <div class="gridarea__small__content">
                                                                <h6><?php echo e($course->author->first_name); ?><?php echo e($course->author->last_name); ?></h6>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-center">Курсы не найдены.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- второй таб -->
                        <div class="tab-pane fade" id="projects__two" role="tabpanel" aria-labelledby="projects__two">
                            <!-- можешь при необходимости вставить другой шаблон списка -->
                            <p>Другой вид отображения курсов пока не реализован.</p>
                        </div>
                    </div>

                    <div class="main__pagination__wrapper" data-aos="fade-up">
                        <?php echo e($courses->links('vendor.pagination.custom')); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- course__section__end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel-6-2-5\OSPanel\home\znatok-kg\resources\views/course.blade.php ENDPATH**/ ?>