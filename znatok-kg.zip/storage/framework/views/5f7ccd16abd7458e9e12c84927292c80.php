<?php $__env->startSection('title', 'Результат теста | Znatok-KG '); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="lesson__quiz__wrap">
            <h3>Результат теста</h3>
            <p>Вы правильно ответили на <strong><?php echo e($correctCount); ?></strong> из <strong><?php echo e($totalQuestions); ?></strong> вопросов.</p>

            <a href="<?php echo e(route('course.test.show', $test->id)); ?>" class="default__button mb-4">
                Пройти заново
            </a>

            <?php $__currentLoopData = $test->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="quiz__single__attemp mb-4">
                    <hr />
                    <h4><?php echo e($qIndex + 1); ?>. <?php echo e($question->text); ?></h4>
                    <div class="row">
                        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        disabled
                                        <?php if($answer->is_correct): ?> checked <?php endif; ?>
                                    />
                                    <label
                                        class="form-check-label"
                                        style="color: <?php echo e($answer->is_correct ? 'green' : 'inherit'); ?>"
                                    >
                                        <?php echo e($answer->text); ?>

                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel-6-2-5\OSPanel\home\znatok-kg\resources\views/users/test/result.blade.php ENDPATH**/ ?>